from shop.models import ShippingAddress
from django.contrib.auth import forms
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from .forms import UserRegisterForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages


def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('shop-home')
             
    return render(request, 'user/login.html')

def register(request):
    form = UserRegisterForm()

    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()

    context = {'form': form}
    return render(request, 'user/register.html', context)

@login_required
def profile(request):
    customer = request.user.customer
    address = ShippingAddress.objects.filter(customer=customer).first()
    context = {'address': address}
    return render(request, 'user/profile.html', context)



