from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='shop-home'),
    path('category/', views.category, name='shop-category'),
    path('product-detail/', views.product_detail, name='shop-product-detail'),
    path('product-checkout/', views.product_checkout, name='shop-product-checkout'),
    path('shopping-cart/', views.shopping_cart, name='shopping-cart'),
    path('confirmation/', views.confirmation, name='order-confirmation'),
    path('update-item/', views.updateItem, name='update-item'),
    path('process-order/', views.processOrder, name='process-order'),
    path('search/', views.search, name='search')
]