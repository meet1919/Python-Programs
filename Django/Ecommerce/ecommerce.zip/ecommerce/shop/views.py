from django import contrib
from django.shortcuts import render, redirect
from .models import *
from django.http import JsonResponse
import json

# Create your views here.
def home(request):
    return render(request, 'shop/home.html')

def category(request):
    products = Product.objects.all()
    context = {'products': products}
    return render(request, 'shop/category.html', context)

def product_detail(request):
    return render(request, 'shop/single-product.html')

def product_checkout(request):
    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(customer=customer, complete=False)
        items = order.orderitem_set.all()
        address = ShippingAddress.objects.filter(customer=customer).first()
    else:
        items = []
        order = {'get_cart_total': 0}
        address = []
        customer = []
    
    context = {'items': items, 'order': order, 'address': address, 'customer': customer}
    return render(request, 'shop/checkout.html', context)

def shopping_cart(request):
    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(customer=customer, complete=False)
        items = order.orderitem_set.all()
        context = {'items': items, 'order': order}
        return render(request, 'shop/cart.html', context)
    else:
        items = []
        order = {'get_cart_total': 0}
        return redirect('login')

def confirmation(request):
    return render(request, 'shop/confirmation.html')

def updateItem(request):
    data = json.loads(request.body)
    productId = data['productId']
    action = data['action']

    print('Action:', action)
    print('productId:', productId)

    customer = request.user.customer
    product = Product.objects.get(id=productId)
    order, created = Order.objects.get_or_create(customer=customer, complete=False)

    orderItem, created = OrderItem.objects.get_or_create(order=order, product=product)

    if action == 'add':
        orderItem.quantity = (orderItem.quantity + 1)
    elif action == 'remove':
        orderItem.quantity = (orderItem.quantity - 1)
    
    orderItem.save()

    if orderItem.quantity <= 0:
        orderItem.delete()

    return JsonResponse('Item was added', safe=False)

def processOrder(request):
    customer = request.user.customer
    context = {'customer': customer}
    return render(request, 'shop/orderprocess.html', context)

def search(request):
    if request.method == 'POST':
        search = request.POST.get('searchquery')
        products = Product.objects.filter(name__contains = search)

        context = {'products': products, 'search': search}
        return render(request, 'shop/search.html', context)
    else:
        context = {}
        return render(request, 'shop/search.html', context)
